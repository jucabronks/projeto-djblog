class MetricType:
    COUNT = "c"
    GAUGE = "g"
    SET = "s"

"""
Função AWS Lambda para coleta de notícias automatizada, com integração Datadog, resumo automático com IA, revisão ortográfica e persistência no MongoDB.

Como usar:
1. Instale o layer/pacote Datadog na Lambda (veja README)
2. Configure as variáveis de ambiente na Lambda:
   - MONGO_URI: string de conexão do MongoDB (produção ou teste)
   - OPENAI_API_KEY: chave da OpenAI (opcional)
   - DD_API_KEY: chave do Datadog
   - DD_SITE: datadoghq.com ou datadoghq.eu
   - DD_ENV: prod ou test
3. Faça upload deste arquivo como função Lambda (Python 3.8+)
4. Agende via EventBridge (CloudWatch Events) para rodar periodicamente
"""

import os
import feedparser
from datetime import datetime
from pymongo import MongoClient
from datadog_lambda.wrapper import datadog_lambda_wrapper
from langdetect import detect
import requests
from difflib import SequenceMatcher
import boto3
from utils import buscar_fontes
import logging

try:
    from summarize_ai import resumir_com_ia
except ImportError:
    resumir_com_ia = None

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger()

# Configurações via variáveis de ambiente
MONGO_URI = os.environ.get("MONGO_URI")
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")
NICHOS = os.environ.get("NICHOS", "saude,esportes,tecnologia,economia").split(",")
PAIS = os.environ.get("PAIS")
MAX_NEWS_PER_SOURCE = int(os.environ.get("MAX_NEWS_PER_SOURCE", 3))

COPYS_API_USER = os.environ.get("COPYS_API_USER")
COPYS_API_KEY = os.environ.get("COPYS_API_KEY")

THRESHOLD_CARACTERES = 250

def validar_variaveis_obrigatorias(nomes):
    faltando = [v for v in nomes if not os.environ.get(v)]
    if faltando:
        raise ValueError(f"Variáveis de ambiente obrigatórias não definidas: {', '.join(faltando)}")

def checar_plagio_copyscape(texto, api_user, api_key):
    url = "https://www.copyscape.com/api/"
    params = {
        "u": api_user,
        "k": api_key,
        "o": "csearch",
        "t": texto[:10000]
    }
    try:
        response = requests.post(url, data=params, timeout=10)
        if "<result>" in response.text and "<count>0</count>" in response.text:
            return False  # Não é plágio
        return True  # Possível plágio
    except Exception as e:
        logger.error(f"Erro ao acessar Copyscape: {e}")
        return False

def traduzir_amazon(texto, idioma_destino):
    translate = boto3.client('translate')
    try:
        response = translate.translate_text(
            Text=texto,
            SourceLanguageCode='auto',
            TargetLanguageCode=idioma_destino
        )
        return response['TranslatedText']
    except Exception as e:
        print(f"Erro ao traduzir com Amazon Translate: {e}")
        return texto

def checar_plagio_local(title, resumo, collection):
    try:
        for noticia_existente in collection.find({}, {"titulo": 1, "resumo": 1}):
            sim_titulo = SequenceMatcher(None, noticia_existente.get("titulo", ""), title).ratio()
            sim_resumo = SequenceMatcher(None, noticia_existente.get("resumo", ""), resumo).ratio()
            if sim_titulo > 0.8 or sim_resumo > 0.8:
                return True
        return False
    except Exception as e:
        logger.error(f"Erro ao checar plágio local: {e}")
        return False

@datadog_lambda_wrapper
def lambda_handler(event, context):
    total_salvas = 0
    total_existentes = 0
    
    # Validar variáveis obrigatórias
    validar_variaveis_obrigatorias(["MONGO_URI", "NICHOS"])
    
    try:
        client = MongoClient(MONGO_URI)
        db = client.get_default_database()
        collection = db["noticias_coletadas"]
    except Exception as e:
        logger.error(f"Erro ao conectar no MongoDB: {e}")
        raise
        
    try:
        for nicho in NICHOS:
            for fonte in buscar_fontes(nicho=nicho):
                if not fonte.get("rss"):
                    continue
                # Verificar se o RSS é realmente acessível
                try:
                    feed = feedparser.parse(fonte["rss"])
                    if not feed.entries:
                        logger.warning(f"Fonte sem dados ou RSS inacessível: {fonte['name']} ({fonte['rss']})")
                        continue
                except Exception as e:
                    logger.error(f"Erro ao acessar RSS de {fonte['name']}: {e}")
                    continue
                for entry in feed.entries[:3]:
                    title = entry.get("title", "(Sem título)")
                    link = entry.get("link", "")
                    description = entry.get("summary", "")
                    resumo = " ".join(description.split()[:60]) + ("..." if len(description.split()) > 60 else "")
                    is_plagio_local = checar_plagio_local(title, resumo, collection)
                    plagio_copyscape = False
                    aprovado = False
                    if not is_plagio_local and COPYS_API_USER and COPYS_API_KEY and len(resumo) > THRESHOLD_CARACTERES:
                        try:
                            plagio_copyscape = checar_plagio_copyscape(resumo, COPYS_API_USER, COPYS_API_KEY)
                            aprovado = not plagio_copyscape
                        except Exception as e:
                            logger.error(f"Erro ao checar plágio Copyscape: {e}")
                            aprovado = False
                    else:
                        aprovado = not is_plagio_local
                    noticia = {
                        "titulo": title,
                        "link": link,
                        "resumo": resumo,
                        "fonte": fonte["name"],
                        "nicho": nicho,
                        "data_insercao": datetime.utcnow(),
                        "aprovado": aprovado,
                        "plagio_local": is_plagio_local,
                        "plagio_copyscape": plagio_copyscape
                    }
                    try:
                        if noticia["aprovado"] and not collection.find_one({"link": noticia["link"]}):
                            collection.insert_one(noticia)
                            total_salvas += 1
                        else:
                            total_existentes += 1
                    except Exception as e:
                        logger.error(f"Erro ao salvar notícia no MongoDB: {e}")
        logger.info(f"Notícias salvas: {total_salvas}, já existentes/plágio: {total_existentes}")
        return {"salvas": total_salvas, "existentes": total_existentes}
    finally:
        client.close() 
import os
import json
import logging
from pymongo import MongoClient
from difflib import SequenceMatcher

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger()

def validar_variaveis_obrigatorias(nomes):
    faltando = [v for v in nomes if not os.environ.get(v)]
    if faltando:
        raise ValueError(f"Variáveis de ambiente obrigatórias não definidas: {', '.join(faltando)}")

# Variáveis obrigatórias para futura integração
VARIAVEIS_OBRIGATORIAS = [
    "MONGO_URI",
    # "WP_URL", "WP_USER", "WP_APP_PASSWORD", "CATEGORIAS_WP"  # Descomente quando o WordPress estiver pronto
]

validar_variaveis_obrigatorias(VARIAVEIS_OBRIGATORIAS)

# Exemplo de nichos e categorias (ajuste conforme seu projeto)
NICHOS = os.environ.get("NICHOS", "saude,esportes,tecnologia,economia").split(",")
# CATEGORIAS_WP = json.loads(os.environ["CATEGORIAS_WP"])  # Descomente quando usar WordPress

def conectar_mongo():
    try:
        client = MongoClient(os.environ["MONGO_URI"])
        db = client.get_default_database()
        collection = db["noticias_coletadas"]
        return client, collection
    except Exception as e:
        logger.error(f"Erro ao conectar no MongoDB: {e}")
        raise

def is_duplicate(noticia, collection):
    for existente in collection.find({"publicado": True}):
        sim_titulo = SequenceMatcher(None, existente.get("titulo", ""), noticia["titulo"]).ratio()
        sim_resumo = SequenceMatcher(None, existente.get("resumo", ""), noticia["resumo"]).ratio()
        if sim_titulo > 0.8 or sim_resumo > 0.8:
            return True
    return False

def lambda_handler(event, context):
    """
    Publica 1 post por nicho (aba/categoria) por execução, 3x por semana.
    Cada post corresponde ao nicho específico, evitando duplicidade.
    """
    client = None
    try:
        client, collection = conectar_mongo()
        publicadas = 0
        duplicadas = 0
        for nicho in NICHOS:
            noticia = collection.find_one({
                "nicho": nicho,
                "aprovado": True,
                "publicado": {"$ne": True},
                "duplicada": {"$ne": True}
            }, sort=[("data_insercao", -1)])
            if not noticia:
                continue
            if is_duplicate(noticia, collection):
                logger.info(f"Notícia duplicada detectada: {noticia['titulo']}")
                collection.update_one({"_id": noticia["_id"]}, {"$set": {"duplicada": True}})
                duplicadas += 1
                continue
            # TODO: Implementar integração com WordPress
            # Exemplo:
            # categoria_id = CATEGORIAS_WP.get(nicho)
            # payload = {
            #     "title": noticia["titulo"],
            #     "content": noticia["resumo"],
            #     "categories": [categoria_id],
            #     "status": "publish"
            # }
            # resp = requests.post(WP_URL, auth=(WP_USER, WP_APP_PASSWORD), json=payload, timeout=10)
            # if resp.status_code == 201:
            #     collection.update_one({"_id": noticia["_id"]}, {"$set": {"publicado": True}})
            #     publicadas += 1
            # else:
            #     logger.error(f"Falha ao publicar: {resp.status_code} - {resp.text}")
            # Simulação de publicação:
            collection.update_one({"_id": noticia["_id"]}, {"$set": {"publicado": True}})
            publicadas += 1
        logger.info(f"Notícias publicadas: {publicadas}, duplicadas: {duplicadas}")
        return {"status": "ok", "publicadas": publicadas, "duplicadas": duplicadas}
    except Exception as e:
        logger.error(f"Erro na execução da Lambda de publicação: {e}")
        return {"status": "erro", "detalhe": str(e)}
    finally:
        if client:
            client.close() 
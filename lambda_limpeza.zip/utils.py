import logging
from pymongo import MongoClient
import os

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger()

def buscar_fontes(nicho=None):
    try:
        client = MongoClient(os.environ["MONGO_URI"])
        db = client.get_default_database()
        query = {"ativo": True}
        if nicho:
            query["nicho"] = nicho
        fontes = list(db["fontes_noticias"].find(query))
        client.close()
        return fontes
    except Exception as e:
        logger.error(f"Erro ao buscar fontes no MongoDB: {e}")
        return []

# Exemplos de uso:
if __name__ == "__main__":
    print("Fontes de tecnologia do Brasil:")
    for f in buscar_fontes(nicho="tecnologia"):
        print(f"- {f['name']} ({f.get('type', '')})")

    print("\nFontes de redes sociais internacionais:")
    for f in buscar_fontes(nicho="redes_sociais"):
        print(f"- {f['name']} ({f.get('type', '')})") 